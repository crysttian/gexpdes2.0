#' Experimentos sistematicos com 3 fatores
#'
#' \code{sis3} Analisa experimentos sistematicos com 3 fatores.
#' @param fator1 Vetor numerico ou complexo contendo os niveis
#' do fator 1.
#' @param fator2 Vetor numerico ou complexo contendo os niveis
#' do fator 2.
#' @param fator3 Vetor numerico ou complexo contendo os niveis
#' do fator 3.
#' @param repet Vetor numerico ou complexo contendo as
#' repeticoes.
#' @param resp Vetor numerico ou complexo contendo a variavel
#' resposta.
#' @param quali Logico, se TRUE (default) na primeira posicao,
#' os niveis do fator 1 sao entendidos como qualitativos, se
#' FALSE, quantitativos; da mesma forma, a segunda posicao e
#' referente aos niveis do fator 2, e a terceira posicao
#' referente aos niveis do fator 3.
#' @param mcomp Permite escolher o teste de comparacao
#' multipla; o \emph{default} e o teste de Tukey, contudo
#' tem-se como outras opcoes: o teste LSD ('lsd'), o teste
#' LSDB ('lsdb'), o teste de Duncan ('duncan'), o teste de SNK
#' ('snk'), o teste de Scott-Knott ('sk'), o teste de
#' comparacoes multiplas bootstrap ('ccboot') e o teste de
#' Calinski e Corsten baseado na distribuicao F ('ccf').
#' @param fac.names Permite nomear os fatores 1 e 2.
#' @param sigT Significancia a ser adotada pelo teste de
#' comparacao multipla de medias; o default e 5\%.
#' @param sigF Significancia a ser adotada pelo teste F da
#' ANAVA; o default e 5\%.
#' @param unfold Orienta os desdobramentos apos a analise de
#' variancia. Se NULL (\emph{default}), sao feitas as analises
#' recomendadas; se '0', e feita apenas a analise de variancia;
#' se '1', os efeitos simples sao estudados; se '2', a interacao
#' dupla e estudada.
#' @author Eric B Ferreira,
#'  \email{eric.ferreira@@unifal-mg.edu.br}
#' @note O \code{\link{graficos}} pode ser usado para
#' construir os graficos da regressao e o
#' \code{\link{plotres}} para analise do residuo da anava.
#' @seealso \code{\link{dbc}}, \code{\link{dbc}},
#' \code{\link{fat2.dbc}}, \code{\link{fat3.dbc}},
#' \code{\link{psub2.dbc}}, \code{\link{fat2.ad.dbc}} e
#' \code{\link{fat3.ad.dbc}}.
#' @examples
#' data(ex11)
#' attach(ex11)
#' out<-sis3(fator1=SSP, fator2=D, fator3=P,
#'           repet=Trans, resp=CMOP,
#'           quali = c(TRUE,TRUE,TRUE),
#'           mcomp = "tukey",
#'           fac.names = c("Sistema","Distancia","Profundidade"),
#'           sigT = 0.05, sigF = 0.05, unfold=NULL)
#' plotres(out)
#' @export

sis3<-function(fator1,
               fator2,
               fator3,
               repet,
               resp,
               quali=c(TRUE,TRUE,TRUE),
               mcomp='tukey',
               fac.names=c('F1','F2','F3'),
               sigT=0.05,
               sigF=0.05,
               unfold=NULL) {

cat('------------------------------------------------------------------------\nLegenda:\n')
cat('FATOR 1: ',fac.names[1],'\n')
cat('FATOR 2: ',fac.names[2],'\n')
cat('FATOR 3: ',fac.names[3],'\n------------------------------------------------------------------------\n\n')

cont<-c(1,3,5)  #linhas dos fatores F1,F2,F3
Fator1<-factor(fator1)
Fator2<-factor(fator2)
Fator3<-factor(fator3)
repet<-factor(repet)
trat<-paste(fator1,fator2,fator3,sep='')
nv1<-length(summary(Fator1))   #Diz quantos niveis tem o fator 1.
nv2<-length(summary(Fator2))   #Diz quantos niveis tem o fator 2.
nv3<-length(summary(Fator3))   #Diz quantos niveis tem o fator 3.

J<-(length(resp))/(nv1*nv2*nv3)

lf1<-levels(Fator1)
lf2<-levels(Fator2)
lf3<-levels(Fator3)

anava<-aov(resp ~ Fator1*Fator2*Fator3
           + Fator1:repet
           + Fator2:repet
           + Fator3:repet
           + Fator1*Fator2:repet
           + Fator1*Fator3:repet
           + Fator2*Fator3:repet)
tab1<-summary(anava)
tab<-tab1[[1]][c(1,7,2,8,3,9,4,11,5,12,6,13,10,14),]

#gl
gla=tab[1,1]
glb=tab[3,1]
glc=tab[5,1]
glab=tab[7,1]
glac=tab[9,1]
glbc=tab[11,1]
glabc=tab[13,1]
glE1=tab[2,1]
glE2=tab[4,1]
glE3=tab[6,1]
glE4=tab[8,1]
glE5=tab[10,1]
glE6=tab[12,1]
glE7=tab[14,1]
glT=gla+glb+glc+glab+glac+glbc+glabc+glE1+glE2+glE3+glE4+glE5+glE6+glE7

#SQ
SQE1=tab[2,2]
SQE2=tab[4,2]
SQE3=tab[6,2]
SQE4=tab[8,2]
SQE5=tab[10,2]
SQE6=tab[12,2]
SQE7=tab[14,2]

#QM
QME1=tab[2,3]
QME2=tab[4,3]
QME3=tab[6,3]
QME4=tab[8,3]
QME5=tab[10,3]
QME6=tab[12,3]
QME7=tab[14,3]

#Fc
Fca=tab[1,3]/tab[2,3]
Fcb=tab[3,3]/tab[4,3]
Fcc=tab[5,3]/tab[6,3]
Fcab=tab[7,3]/tab[8,3]
Fcac=tab[9,3]/tab[10,3]
Fcbc=tab[11,3]/tab[12,3]
Fcabc=tab[13,3]/tab[14,3]
tab[,4]<-c(Fca, NA, Fcb, NA, Fcc, NA, Fcab, NA, Fcac, NA,
           Fcbc, NA, Fcabc, NA)

#valorp
pvalor<-c(1-pf(Fca,gla,glE1), 1-pf(Fcb,glb,glE2),
          1-pf(Fcc,glc,glE3), 1-pf(Fcab,glab,glE4),
          1-pf(Fcac,glac,glE5), 1-pf(Fcbc,glbc,glE6),
          1-pf(Fcabc,glabc,glE7))
tab[,5]<-c(pvalor[1], NA, pvalor[2], NA,
           pvalor[3], NA, pvalor[4], NA,
           pvalor[5], NA, pvalor[6], NA,
           pvalor[7], NA)
colnames(tab)<-c('GL', 'SQ', 'QM', 'Fc', 'Pr(>Fc)')
tab<-rbind(tab,apply(tab,2,sum))
rownames(tab)<-c(fac.names[1],'Erro a',
                 fac.names[2],'Erro b',
                 fac.names[3],'Erro c',
                 paste(fac.names[1],'*',fac.names[2],sep=''),'Erro d',
                 paste(fac.names[1],'*',fac.names[3],sep=''),'Erro e',
                 paste(fac.names[2],'*',fac.names[3],sep=''),'Erro f',
                 paste(fac.names[1],'*',fac.names[2],'*',fac.names[3],sep=''),'Erro g',
                 'Total')

cv1=round(sqrt(tab[2,3])/mean(resp)*100,2)
cv2=round(sqrt(tab[4,3])/mean(resp)*100,2)
cv3=round(sqrt(tab[6,3])/mean(resp)*100,2)
cv4=round(sqrt(tab[8,3])/mean(resp)*100,2)
cv5=round(sqrt(tab[10,3])/mean(resp)*100,2)
cv6=round(sqrt(tab[12,3])/mean(resp)*100,2)
cv7=round(sqrt(tab[14,3])/mean(resp)*100,2)

cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(round(tab,4))
cat('------------------------------------------------------------------------
CV 1 =',cv1,'%\nCV 2 =', cv2,'%\nCV 3 =', cv3,'%\nCV 4 =',cv1,
'%\nCV 5 =', cv2,'%\nCV 6 =', cv3,'%\nCV 7 =',cv1,'%')

fatores<-data.frame('fator 1' = fator1,'fator 2' = fator2, 'fator 3' = fator3)

###############################################################################################################
#Teste de normalidade
pvalor.shapiro<-shapiro.test(anava$residuals)$p.value
cat('\n------------------------------------------------------------------------
Teste de normalidade dos residuos (Shapiro-Wilk)\n')
cat('p-valor: ',pvalor.shapiro, '\n')
if(pvalor.shapiro<0.05){cat('ATENCAO: a 5% de significancia, os residuos nao podem ser considerados normais!
------------------------------------------------------------------------\n')}
else{cat('De acordo com o teste de Shapiro-Wilk a 5% de significancia, os residuos podem ser considerados normais.
------------------------------------------------------------------------\n')}

# Creating unfold #########################################
if(is.null(unfold)){
  if(1-pf(Fcab,glab,glE4)>sigF &&
     1-pf(Fcac,glac,glE5)>sigF &&
     1-pf(Fcbc,glbc,glE6)>sigF &&
     1-pf(Fcabc,glabc,glE7)>sigF) {unfold<-c(unfold,1)}
  if(1-pf(Fcabc,glabc,glE7)>sigF &&
     1-pf(Fcab,glab,glE4)<=sigF){unfold<-c(unfold,2.1)}
  if(1-pf(Fcabc,glabc,glE7)>sigF &&
     1-pf(Fcac,glac,glE5)<=sigF){unfold<-c(unfold,2.2)}
  if(1-pf(Fcabc,glabc,glE7)>sigF &&
     1-pf(Fcbc,glbc,glE6)<=sigF){unfold<-c(unfold,2.3)}
  if(1-pf(Fcabc,glabc,glE7)<=sigF){unfold<-c(unfold,3)}
}

#Para nenhuma interacao significativa, fazer...
if(any(unfold==1)) {
  cat('\nInteracao nao significativa: analisando os efeitos simples
------------------------------------------------------------------------\n')
  fatores<-data.frame('fator 1'=fator1,'fator 2' = fator2,'fator 3' = fator3)

for(i in 1:3){
#Para os fatores QUALITATIVOS, teste de Tukey
 if(quali[i]==TRUE && pvalor[i]<=sigF) {
    cat(fac.names[i])
   if(mcomp=='tukey'){tukey(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=='duncan'){duncan(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=='lsd'){lsd(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=='lsdb'){lsdb(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=='sk'){scottknott(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=='snk'){snk(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=="ccboot"){ccboot(resp,fatores[,i],tab[8,1],tab[8,2],sigT)}
   if(mcomp=="ccF"){ccF(resp,fatores[,i],tab[8,1],tab[8,2],sigT)
 }
 }

if(quali[i]==TRUE && pvalor[i]>sigF) {
  cat(fac.names[i])
  cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
  cat('------------------------------------------------------------------------\n')
  mean.table<-tapply.stat(resp,fatores[,i],mean)
  colnames(mean.table)<-c('Niveis','Medias')
  print(mean.table)
  cat('------------------------------------------------------------------------')
}

#Para os fatores QUANTITATIVOS, regressao
if(quali[i]==FALSE && pvalor[i]<=sigF){
  cat(fac.names[i])
  reg.poly(resp, fatores[,i], tab[8,1],tab[8,2], tab[i,1], tab[i,2])
}

if(quali[i]==FALSE && pvalor[i]>sigF) {
  cat(fac.names[i])
  cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
  cat('------------------------------------------------------------------------\n')
  mean.table<-tapply.stat(resp,fatores[,i],mean)
  colnames(mean.table)<-c('Niveis','Medias')
  print(mean.table)
  cat('------------------------------------------------------------------------')
}
cat('\n')
}
}

#Se a(s) interacao(Ces) dupla(s) for(em) significativa(s),
#desdobramento:

#Interacao Fator1*Fator2
if(any(unfold==2.1)){
  cat("\n\n\nInteracao",paste(fac.names[1],'*',fac.names[2],sep='')," significativa: desdobrando a interacao
------------------------------------------------------------------------\n")

#Desdobramento de FATOR 1 dentro do niveis de FATOR 2
cat("\nDesdobrando ", fac.names[1], ' dentro de cada nivel de ', fac.names[2], '
------------------------------------------------------------------------\n')

des1<-aov(resp~Fator2/Fator1)
l1<-vector('list',nv2)
names(l1)<-names(summary(Fator2))
v<-numeric(0)
for(j in 1:nv2) {
  for(i in 0:(nv1-2)) v<-cbind(v,i*nv2+j)
  l1[[j]]<-v
  v<-numeric(0)
}
des1.tab<-summary(des1,split=list('Fator2:Fator1'=l1))[[1]]

#Montando a tabela de ANAVA do des1
glf1=c(as.numeric(des1.tab[3:(nv2+2),1]))
SQf1=c(as.numeric(des1.tab[3:(nv2+2),2]))
QMf1=SQf1/glf1
Fcf1=QMf1/QME1
rn<-numeric(0)
for(i in 1:nv2){
rn<-c(rn, paste(paste(fac.names[1],':',fac.names[2],sep=''),
                  lf2[i]))}
glEc<-((QME1+glb*QME2)^2)/((QME1^2/glE1)+(glb*QME2)^2/glE2)
QMEc<-(QME1+glb*QME2)/(glb+1)
SQEc<-glEc*QMEc
anavad1<-data.frame("GL"=c(glf1, glEc),
                    "SQ"=c(round(c(SQf1,SQEc),5)),
                    "QM"=c(round(c(QMf1,QMEc),5)),
                    "Fc"=c(round(Fcf1,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf1,glf1,glEc),4),' '))
colnames(anavad1)[5]="Pr>Fc"
rownames(anavad1)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad1)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv2) {
 ii<-ii+1
 if(1-pf(Fcf1,glf1,glEc)[ii]<=sigF){
   if(quali[1]==TRUE){
cat('\n\n',fac.names[1],' dentro do nivel ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[1],' dentro do nivel ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
reg.poly(resp[Fator2==lf2[i]], fator1[Fator2==lf2[i]],glEc,SQEc, des1.tab[i+2,1], des1.tab[i+2,2])
}
}
else{cat('\n\n',fac.names[1],' dentro do nivel ',lf2[i],' de ',fac.names[2],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[Fator2==lf2[i]],fatores[,1][Fator2==lf2[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}
}
cat('\n\n')

#Desdobramento de FATOR 2 dentro do niveis de FATOR 1
cat("\nDesdobrando ", fac.names[2], ' dentro de cada nivel de ', fac.names[1], '
------------------------------------------------------------------------\n')

des2<-aov(resp~Fator1/Fator2)
l2<-vector('list',nv1)
names(l2)<-names(summary(Fator1))
v<-numeric(0)
for(j in 1:nv1) {
  for(i in 0:(nv2-2)) v<-cbind(v,i*nv1+j)
  l2[[j]]<-v
  v<-numeric(0)
}
des2.tab<-summary(des2,split=list('Fator1:Fator2'=l2))[[1]]

#Montando a tabela de ANAVA do des2
glf2=c(as.numeric(des2.tab[3:(nv1+2),1]))
SQf2=c(as.numeric(des2.tab[3:(nv1+2),2]))
QMf2=SQf2/glf2
Fcf2=QMf2/QME2
glEc<-glE2
QMEc<-QME2
SQEc<-glEc*QMEc

rn<-numeric(0)
for(k in 1:nv1){ rn<-c(rn,
                       paste(paste(fac.names[2],':',fac.names[1],sep=''),
                       lf1[k]))}

anavad2<-data.frame("GL"=c(glf2, glEc),
                    "SQ"=c(round(c(SQf2,SQEc),5)),
                    "QM"=c(round(c(QMf2,QMEc),5)),
                    "Fc"=c(round(Fcf2,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf2,glf2,glEc),4),' '))
colnames(anavad2)[5]="Pr>Fc"
rownames(anavad2)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad2)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv1) {
  ii<-ii+1
  if(1-pf(Fcf2,glf2,glEc)[ii]<=sigF){
    if(quali[2]==TRUE){
cat('\n\n',fac.names[2],' dentro do nivel ',lf1[i],' de ',fac.names[1],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],glEc,SQEc,sigT)}}
else{#regressao
cat('\n\n',fac.names[2],' dentro do nivel ',lf1[i],' de ',fac.names[1],'
------------------------------------------------------------------------')
reg.poly(resp[Fator1==lf1[i]], fator2[Fator1==lf1[i]], glEc,SQEc, des2.tab[i+2,1], des2.tab[i+2,2])
}
}
else{cat('\n\n',fac.names[2],' dentro do nivel ',lf1[i],' de ',fac.names[1],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[Fator1==lf1[i]],fatores[,2][Fator1==lf1[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}
}

#Checar o Fator3
if(pvalor[5]>sigF && pvalor[6]>sigF) {
cat('\nAnalisando os efeitos simples do fator ',fac.names[3],'
------------------------------------------------------------------------\n')

i<-3
{
#Para os fatores QUALITATIVOS, teste de Tukey
if(quali[i]==TRUE && pvalor[i]<=sigF){
cat(fac.names[i])
if(mcomp=='tukey'){tukey(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=='duncan'){duncan(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=='lsd'){lsd(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=='lsdb'){lsdb(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=='sk'){scottknott(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=='snk'){snk(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=="ccboot"){ccboot(resp,fatores[,i],glE3,SQE3,sigT)}
if(mcomp=="ccF"){ccF(resp,fatores[,i],glE3,SQE3,sigT)}
}
if(quali[i]==TRUE && pvalor[i]>sigF) {
cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}

#Para os fatores QUANTITATIVOS, regressao
if(quali[i]==FALSE && pvalor[i]<=sigF){
cat(fac.names[i])
reg.poly(resp, fatores[,i], glE3,SQE3, tab[i,1], tab[i,2])
}

if(quali[i]==FALSE && pvalor[i]>sigF) {
cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}
cat('\n')
}}}

#Interacao Fator1*Fator3
if(any(unfold==2.2)){
cat("\n\n\nInteracao",paste(fac.names[1],'*',fac.names[3],sep='')," significativa: desdobrando a interacao
------------------------------------------------------------------------\n")

#Desdobramento de FATOR 1 dentro do niveis de FATOR 3
cat("\nDesdobrando ", fac.names[1], ' dentro de cada nivel de ', fac.names[3], '
------------------------------------------------------------------------\n')

des3<-aov(resp~Fator3/Fator1)
l1<-vector('list',nv3)
names(l1)<-names(summary(Fator3))
v<-numeric(0)
for(j in 1:nv3) {
  for(i in 0:(nv1-2)) v<-cbind(v,i*nv3+j)
  l1[[j]]<-v
  v<-numeric(0)
}
des3.tab<-summary(des3,split=list('Fator3:Fator1'=l1))[[1]]

#Montando a tabela de ANAVA do des3
glf3=c(as.numeric(des3.tab[3:(nv3+2),1]))
SQf3=c(as.numeric(des3.tab[3:(nv3+2),2]))
QMf3=SQf3/glf3
Fcf3=QMf3/QME3

glEc<-((QME1+glc*QME3)^2)/((QME1^2/glE1)+(glc*QME3)^2/glE3)
QMEc<-(QME1+glc*QME3)/(glc+1)
SQEc<-glEc*QMEc

rn<-numeric(0)
for(j in 1:nv3){ rn<-c(rn, paste(paste(fac.names[1],':',fac.names[3],sep=''),lf3[j]))}

anavad3<-data.frame("GL"=c(glf3, glEc),
                    "SQ"=c(round(c(SQf3,SQEc),5)),
                    "QM"=c(round(c(QMf3,QMEc),5)),
                    "Fc"=c(round(Fcf3,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf3,glf3,glEc),4),''))
colnames(anavad3)[5]="Pr>Fc"
rownames(anavad3)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad3)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv3) {
 ii<-ii+1
   if(1-pf(Fcf3,glf3,glEc)[ii]<=sigF){
     if(quali[1]==TRUE){
cat('\n\n',fac.names[1],' dentro do nivel ',lf3[i],' de ',fac.names[3],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],glEc,SQEc,sigT)}}
else{#regressao
cat('\n\n',fac.names[1],' dentro do nivel ',lf3[i],' de ',fac.names[3],'
------------------------------------------------------------------------')
reg.poly(resp[Fator3==lf3[i]], fator1[Fator3==lf3[i]], glEc,SQEc, des3.tab[i+2,1], des3.tab[i+2,2])
}}
else{cat('\n\n',fac.names[1],' dentro do nivel ',lf3[i],' de ',fac.names[3],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[Fator3==lf3[i]],fatores[,1][Fator3==lf3[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}
}
cat('\n\n')

#Desdobramento de FATOR 3 dentro dos niveis de FATOR 1
cat("\nDesdobrando ", fac.names[3], ' dentro de cada nivel de ', fac.names[1], '
------------------------------------------------------------------------\n')

des4<-aov(resp~Fator1/Fator3)
l3<-vector('list',nv1)
names(l3)<-names(summary(Fator1))
v<-numeric(0)
for(j in 1:nv1) {
  for(i in 0:(nv3-2)) v<-cbind(v,i*nv1+j)
  l3[[j]]<-v
  v<-numeric(0)
}
des4.tab<-summary(des4,split=list('Fator1:Fator3'=l3))[[1]]

#Montando a tabela de ANAVA do des4
glf4=c(as.numeric(des4.tab[3:(nv1+2),1]))
SQf4=c(as.numeric(des4.tab[3:(nv1+2),2]))
QMf4=SQf4/glf4
Fcf4=QMf4/QME4
glEc<-glE3
QMEc<-QME3
SQEc<-glEc*QMEc

rn<-numeric(0)
for(k in 1:nv1){ rn<-c(rn, paste(paste(fac.names[3],':',fac.names[1],sep=''),lf1[k]))}

anavad4<-data.frame("GL"=c(glf4, glEc),
                    "SQ"=c(round(c(SQf4,SQEc),5)),
                    "QM"=c(round(c(QMf4,QMEc),5)),
                    "Fc"=c(round(Fcf4,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf4,glf4,glEc),4),' '))
colnames(anavad4)[5]="Pr>Fc"
rownames(anavad4)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad4)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv1) {
  ii<-ii+1
  if(1-pf(Fcf4,glf4,glEc)[ii]<=sigF){
    if(quali[3]==TRUE){
      cat('\n\n',fac.names[3],' dentro do nivel ',lf1[i],' de ',fac.names[1],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[3],' dentro do nivel ',lf1[i],' de ',fac.names[1],'
------------------------------------------------------------------------')
reg.poly(resp[Fator1==lf1[i]], fator3[Fator1==lf1[i]], glEc,SQEc, des4.tab[i+2,1], des4.tab[i+2,2])
}}
else{cat('\n\n',fac.names[3],' dentro do nivel ',lf1[i],' de ',fac.names[1],'\n')
    cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
    cat('------------------------------------------------------------------------\n')
    mean.table<-tapply.stat(resp[Fator1==lf1[i]],fatores[,3][Fator1==lf1[i]],mean)
    colnames(mean.table)<-c('Niveis','Medias')
    print(mean.table)
    cat('------------------------------------------------------------------------\n')
}}

#Checar o Fator2
if(pvalor[4]>sigF && pvalor[6]>sigF) {
cat('\nAnalisando os efeitos simples do fator ',fac.names[2],'
------------------------------------------------------------------------\n')

i<-2
{
#Para os fatores QUALITATIVOS, teste de Tukey
if(quali[i]==TRUE && pvalor[i]<=sigF) {
  cat(fac.names[i])
if(mcomp=='tukey'){tukey(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=='duncan'){duncan(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=='lsd'){lsd(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=='lsdb'){lsdb(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=='sk'){scottknott(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=='snk'){snk(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=="ccboot"){ccboot(resp,fatores[,i],glE2,SQE2,sigT)}
if(mcomp=="ccF"){ccF(resp,fatores[,i],glE2,SQE2,sigT)}
}

if(quali[i]==TRUE && pvalor[i]>sigF) {
cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}

#Para os fatores QUANTITATIVOS, regressao
if(quali[i]==FALSE && pvalor[i]<=sigF){
cat(fac.names[i])
reg.poly(resp, fatores[,i], glE2,SQE2, tab[i,1], tab[i,2])
}

if(quali[i]==FALSE && pvalor[i]>sigF) {
cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}
cat('\n')
}}}

#Interacao Fator2*Fator3
if(any(unfold==2.3)){
cat("\n\n\nInteracao",paste(fac.names[2],'*',fac.names[3],sep='')," significativa: desdobrando a interacao
------------------------------------------------------------------------\n")

#Desdobramento de FATOR 2 dentro do niveis de FATOR 3
cat("\nDesdobrando ", fac.names[2], ' dentro de cada nivel de ', fac.names[3], '
------------------------------------------------------------------------\n')
des5<-aov(resp~Fator3/Fator2)
l2<-vector('list',nv3)
names(l2)<-names(summary(Fator3))
v<-numeric(0)
for(j in 1:nv3) {
  for(i in 0:(nv2-2)) v<-cbind(v,i*nv3+j)
  l2[[j]]<-v
  v<-numeric(0)
}
des5.tab<-summary(des5,split=list('Fator3:Fator2'=l2))[[1]]

#Montando a tabela de ANAVA do des5
glf5=c(as.numeric(des5.tab[3:(nv3+2),1]))
SQf5=c(as.numeric(des5.tab[3:(nv3+2),2]))
QMf5=SQf5/glf5
Fcf5=QMf5/QME5
glEc<-((QME2+glc*QME3)^2)/((QME2^2/glE2)+(glc*QME3)^2/glE3)
QMEc<-(QME2+glc*QME3)/(glc+1)
SQEc<-glEc*QMEc

rn<-numeric(0)
for(j in 1:nv3){ rn<-c(rn, paste(paste(fac.names[2],':',fac.names[3],sep=''),lf3[j]))}
anavad5<-data.frame("GL"=c(glf5, glEc),
                    "SQ"=c(round(c(SQf5,SQEc),5)),
                    "QM"=c(round(c(QMf5,QMEc),5)),
                    "Fc"=c(round(Fcf5,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf5,glf5,glEc),4),' '))
colnames(anavad5)[5]="Pr>Fc"
rownames(anavad5)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad5)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv3) {
  ii<-ii+1
  if(1-pf(Fcf5,glf5,glEc)[ii]<=sigF){
    if(quali[2]==TRUE){
cat('\n\n',fac.names[2],' dentro do nivel ',lf3[i],' de ',fac.names[3],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[2],' dentro do nivel ',lf3[i],' de ',fac.names[3],'
------------------------------------------------------------------------')
reg.poly(resp[Fator3==lf3[i]], fator2[Fator3==lf3[i]], glEc,SQEc, des5.tab[i+2,1], des5.tab[i+2,2])
}}
else{cat('\n\n',fac.names[2],' dentro do nivel ',lf3[i],' de ',fac.names[3],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[Fator3==lf3[i]],fatores[,2][Fator3==lf3[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}}
cat('\n\n')

#Desdobramento de FATOR 3 dentro do niveis de FATOR 2
cat("\nDesdobrando ", fac.names[3], ' dentro de cada nivel de ', fac.names[2], '
------------------------------------------------------------------------\n')
des6<-aov(resp~Fator2/Fator3)
l3<-vector('list',nv2)
names(l3)<-names(summary(Fator2))
v<-numeric(0)
for(j in 1:nv2) {
  for(i in 0:(nv3-2)) v<-cbind(v,i*nv2+j)
  l3[[j]]<-v
  v<-numeric(0)
}
des6.tab<-summary(des6,split=list('Fator2:Fator3'=l3))[[1]]

#Montando a tabela de ANAVA do des6
glf6=c(as.numeric(des6.tab[3:(nv2+2),1]))
SQf6=c(as.numeric(des6.tab[3:(nv2+2),2]))
QMf6=SQf6/glf6
Fcf6=QMf6/QME6
glEc<-glE3
QMEc<-QME3
SQEc<-glEc*QMEc

rn<-numeric(0)
for(i in 1:nv2){ rn<-c(rn, paste(paste(fac.names[3],':',fac.names[2],sep=''),lf2[i]))}

anavad6<-data.frame("GL"=c(glf6, glEc),
                    "SQ"=c(round(c(SQf6,SQEc),5)),
                    "QM"=c(round(c(QMf6,QMEc),5)),
                    "Fc"=c(round(Fcf6,4),''),
                    "Pr>Fc"=c(round(1-pf(Fcf6,glf6,glEc),4),' '))
colnames(anavad6)[5]="Pr>Fc"
rownames(anavad6)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad6)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv2) {
  ii<-ii+1
  if(1-pf(Fcf6,glf6,glEc)[ii]<=sigF){
    if(quali[3]==TRUE){
cat('\n\n',fac.names[3],' dentro do nivel ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[3],' dentro do nivel ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
reg.poly(resp[Fator2==lf2[i]], fator3[Fator2==lf2[i]], glEc,SQEc, des6.tab[i+2,1], des6.tab[i+2,2])
}}
else{cat('\n\n',fac.names[3],' dentro do nivel ',lf2[i],' de ',fac.names[2],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[Fator2==lf2[i]],fatores[,3][Fator2==lf2[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}}

#Checar o Fator1
if(pvalor[4]>sigF && pvalor[5]>sigF) {
cat('\nAnalisando os efeitos simples do fator ',fac.names[1],'
------------------------------------------------------------------------\n')

i<-1
{
#Para os fatores QUALITATIVOS, teste de Tukey
if(quali[i]==TRUE && pvalor[i]<=sigF) {
    cat(fac.names[i])
if(mcomp=='tukey'){tukey(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=='duncan'){duncan(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=='lsd'){lsd(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=='lsdb'){lsdb(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=='sk'){scottknott(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=='snk'){snk(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=="ccboot"){ccboot(resp,fatores[,i],glE1,SQE1,sigT)}
if(mcomp=="ccF"){ccF(resp,fatores[,i],glE1,SQE1,sigT)}
}

if(quali[i]==TRUE && pvalor[i]>sigF) {
    cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}

#Para os fatores QUANTITATIVOS, regressao
if(quali[i]==FALSE && pvalor[i]<=sigF){
cat(fac.names[i])
reg.poly(resp, fatores[,i], glE1,SQE1, tab[i,1], tab[i,2])
}

if(quali[i]==FALSE && pvalor[i]>sigF) {
  cat(fac.names[i])
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp,fatores[,i],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------')
}
cat('\n')
}}}

#Para interacao tripla significativa, desdobramento
if(any(unfold==3)){
cat("\n\n\nInteracao",paste(fac.names[1],'*',fac.names[2],'*',fac.names[3],sep='')," significativa: desdobrando a interacao
------------------------------------------------------------------------\n")

#Desdobramento de FATOR 1 dentro do niveis de FATOR 2 e do FATOR 3
cat("\nDesdobrando ", fac.names[1], ' dentro de cada nivel de ', fac.names[2], 'e',fac.names[3],'
------------------------------------------------------------------------\n')
SQc<-numeric(0)
SQf<-numeric(nv2*nv3)

rn<-numeric(0)
for(i in 1:nv2){
  for(j in 1:nv3) {
    for(k in 1:nv1) {
  SQf[(i-1)*nv3+j]=c(SQf[(i-1)*nv3+j]+ sum(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j] & fatores[,1]==lf1[k]])^2) }
  rn<-c(rn, paste(paste(fac.names[1],':',sep=''),lf2[i],lf3[j]))
  SQc=c(SQc,(sum(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]])^2)/(nv1*J))
}}
SQf=SQf/J
SQ=SQf-SQc
glf=rep(nv1-1,(nv2*nv3))
QM=SQ/glf
glEc<-((QME1+glb*QME2+(glb+1)*glc*QME3)^2)/((QME1^2/glE1)+(glb*QME2)^2/glE2+((glb+1)*glc*QME3)^2/glE3)
QMEc<-(QME1+glb*QME2+(glb+1)*glc*QME3)/((glb+1)*(glc+1))
SQEc<-glEc*QMEc

#Montando a tabela de ANAVA do des7
anavad7<-data.frame("GL"=c(glf,glEc),
                    "SQ"=c(SQ,SQEc),
                    "QM"=c(QM,QMEc),
                    "Fc"=c(c(round((QM/QME7),6)), ' '),
                    "Pr>Fc"=c(c(round(1-pf(QM/QME7,glf,glEc),6)),' '))
colnames(anavad7)[5]="Pr>Fc"
rownames(anavad7)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad7)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(i in 1:nv2) {
  for(j in 1:nv3) {
    ii<-ii+1
    if(1-pf(QM/QME7,glf,glEc)[ii]<=sigF){
      if(quali[1]==TRUE){
cat('\n\n',fac.names[1],' dentro da combinacao dos niveis ',lf2[i],' de ',fac.names[2],' e ',lf3[j],' de ',fac.names[3],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]],fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[1],' dentro da combinacao dos niveis ',lf2[i],' de ',fac.names[2],' e ',lf3[j],' de ',fac.names[3],'
------------------------------------------------------------------------')
reg.poly(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]], fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]], glEc,SQEc, nv1-1, SQ[ii])
}}

else{cat('\n\n',fac.names[1],' dentro da combinacao dos niveis ',lf2[i],' de ',fac.names[2],' e ',lf3[j],' de ',fac.names[3],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[fatores[,2]==lf2[i] & fatores[,3]==lf3[j]], fatores[,1][Fator2==lf2[i] & Fator3==lf3[j]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}}}
cat('\n\n')

#Desdobramento de FATOR 2 dentro do niveis de FATOR 1 e FATOR 3
cat("\nDesdobrando ", fac.names[2], ' dentro de cada nivel de ', fac.names[1], 'e',fac.names[3],'
------------------------------------------------------------------------\n')
SQc<-numeric(0)
SQf<-numeric(nv1*nv3)
rn<-numeric(0)

for(k in 1:nv1){
  for(j in 1:nv3) {
    for(i in 1:nv2) {SQf[(k-1)*nv3+j]=c(SQf[(k-1)*nv3+j]+ sum(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j] & fatores[,2]==lf2[i]])^2) }
rn<-c(rn, paste(paste(fac.names[2],':',sep=''),lf1[k],lf3[j]))
SQc=c(SQc,(sum(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]])^2)/(nv2*J))
}}
SQf=SQf/J
SQ=SQf-SQc
glf=rep(nv2-1,(nv1*nv3))
QM=SQ/glf
glEc<-((QME2+glc*QME3)^2)/((QME2^2/glE2)+(glc*QME3)^2/glE3)
QMEc<-(QME2+glc*QME3)/(glc+1)
SQEc<-glEc*QMEc

#Montando a tabela de ANAVA do des8
anavad8<-data.frame("GL"=c(glf,glEc),
                    "SQ"=c(SQ,SQEc),
                    "QM"=c(QM,QMEc),
                    "Fc"=c(c(round((QM/QMEc),6)), ' '),
                    "Pr>Fc"=c(c(round(1-pf(QM/QMEc,glf,glEc),6)),' '))
colnames(anavad8)[5]="Pr>Fc"
rownames(anavad8)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad8)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(k in 1:nv1) {
  for(j in 1:nv3) {
    ii<-ii+1
    if(1-pf(QM/QMEc,glf,glEc)[ii]<=sigF){
      if(quali[2]==TRUE){
cat('\n\n',fac.names[2],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf3[j],' de ',fac.names[3],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[2],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf3[j],' de ',fac.names[3],'
------------------------------------------------------------------------')
reg.poly(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]], glEc,SQEc, nv2-1, SQ[ii])
}}
else{cat('\n\n',fac.names[2],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf3[j],' de ',fac.names[3],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[fatores[,1]==lf1[k] & fatores[,3]==lf3[j]],fatores[,2][Fator1==lf1[k] & fatores[,3]==lf3[j]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}}}

#Desdobramento de FATOR 3 dentro do niveis de FATOR 1 e FATOR 2
cat("\nDesdobrando ", fac.names[3], ' dentro de cada nivel de ', fac.names[1], 'e',fac.names[2],'
------------------------------------------------------------------------\n')
SQc<-numeric(0)
SQf<-numeric(nv1*nv2)
rn<-numeric(0)
for(k in 1:nv1){
  for(i in 1:nv2) {
    for(j in 1:nv3){
SQf[(k-1)*nv2+i]=c(SQf[(k-1)*nv2+i]+ sum(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i] & fatores[,3]==lf3[j]])^2) }
rn<-c(rn, paste(paste(fac.names[3],':',sep=''),lf1[k],lf2[i]))
SQc=c(SQc,(sum(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]])^2)/(nv3*J))
}}
SQf=SQf/J
SQ=SQf-SQc
glf=rep(nv3-1,(nv1*nv2))
QM=SQ/glf
glEc<-glE3
QMEc<-QME3
SQEc<-glEc*QMEc

#Montando a tabela de ANAVA do des9
anavad9<-data.frame("GL"=c(glf,glEc),
                    "SQ"=c(SQ,SQEc),
                    "QM"=c(QM,QMEc),
                    "Fc"=c(c(round((QM/QMEc),6)), ' '),
                    "Pr>Fc"=c(c(round(1-pf(QM/QMEc,glf,glEc),6)),' '))
colnames(anavad9)[5]="Pr>Fc"
rownames(anavad9)=c(rn,"Residuo")
cat('------------------------------------------------------------------------
Quadro da analise de variancia\n------------------------------------------------------------------------\n')
print(anavad9)
cat('------------------------------------------------------------------------\n\n')

ii<-0
for(k in 1:nv1) {
  for(i in 1:nv2) {
    ii<-ii+1
    if(1-pf(QM/QMEc,glf,glEc)[ii]<=sigF){
      if(quali[3]==TRUE){
cat('\n\n',fac.names[3],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
if(mcomp=='tukey'){tukey(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='duncan'){duncan(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsd'){lsd(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='lsdb'){lsdb(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='sk'){scottknott(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=='snk'){snk(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccboot"){ccboot(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
if(mcomp=="ccF"){ccF(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],glEc,SQEc,sigT)}
}
else{#regressao
cat('\n\n',fac.names[3],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf2[i],' de ',fac.names[2],'
------------------------------------------------------------------------')
reg.poly(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]], glEc,SQEc, nv3-1, SQ[ii])
}}
else{cat('\n\n',fac.names[3],' dentro da combinacao dos niveis ',lf1[k],' de ',fac.names[1],' e ',lf2[i],' de ',fac.names[2],'\n')
cat('\nDe acordo com o teste F, as medias desse fator sao estatisticamente iguais.\n')
cat('------------------------------------------------------------------------\n')
mean.table<-tapply.stat(resp[fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],fatores[,3][fatores[,1]==lf1[k] & fatores[,2]==lf2[i]],mean)
colnames(mean.table)<-c('Niveis','Medias')
print(mean.table)
cat('------------------------------------------------------------------------\n')
}}}
}

## error a ##
tabmedia<-model.tables(anava, "means")
#error.plot<-as.vector(t(as.matrix(tabmedia$tables$`Fator1:bloco`)-as.vector(tabmedia$tables$Fator1))-as.vector(tabmedia$tables$bloco))

#Saida
out<-list()
out$residuos<-anava$residuals
#out$residuals.a<-error.plot
out$gl.residual<-anava$df.residual
#out$df.residual.a<-as.numeric(tab[2,1])
out$coeficientes<-anava$coefficients
out$efeitos<-anava$effects
out$valores.ajustados<-anava$fitted.values
out$medias.fator1<-tapply.stat(resp,fatores[,1],mean)
out$medias.fator2<-tapply.stat(resp,fatores[,2],mean)
out$medias.dentro12<-tabmedia$tables$`Fator1:Fator2`
out$trat<-trat
#if(quali==FALSE && tab[[1]][1,5]<sigF) {out$reg<-reg}
invisible(out)
}
