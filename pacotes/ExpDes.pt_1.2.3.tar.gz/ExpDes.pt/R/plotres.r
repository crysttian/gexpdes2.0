#' Conjunto de graficos dos residuos do modelo
#'
#' \code{plotres} Graficos dos residuos da saida do modelo.
#' Conjunto de quatro graficos sao produzidos: (1) Histograma,
#' (2) Grafico da probabilidade normal dos residuos com bandas
#' de confianca pela estatistica de ordem, (3) Residuos
#' Padronizados versus Valores Ajustados e (4) box-plot
#' (Residuos Padronizados).
#' @param a Objeto contendo a saida da analise do experimento,
#' tendo esta sido feita utilizando o pacote ExpDes.pt.
#' @param sep Lógico. Se TRUE (padrao) os dispositivos
#' graficos sao exibidos em uma unica janela grafica. Caso
#' contrario, sao exibidas multiplas janelas.
#' @param col1 Color 1 (background color, usually light,
#'  color).
#' @param col2 Color 2 (front color, usually dark, color).
#' @references STEEL, R. G. D.; TORRIE, J. H. \emph{Principles
#' and procedures in Statistics: a biometrical approach}.
#' McGraw-Hill, New York, NY. 1980.
#' @author Eric B Ferreira,
#'  \email{eric.ferreira@@unifal-mg.edu.br}
#'  @author Denismar Alves Nogueira
#'  @note Esta pode ser utilizada para contrucao dos graficos
#'  dos residuos de qualquer modelo do ExpDes.pt.
#' @seealso \code{\link{graficos}}.
#' @examples
#' data(ex1)
#' attach(ex1)
#' a<-dic(trat, ig)
#' plotres(a)
#' @export

plotres<-function(a,
                  sep=FALSE,
                  col1='brown',
                  col2='blue'){

#Residuos internamente estudentizados
resid<-a$residuos
df.resid<-a$gl.residual
fitted.val<-a$valores.ajustados
var.res<-sum(resid^2)/df.resid
respad<-resid/sqrt(var.res)

par(mar=c(4,4,1,1))

if(sep==FALSE)  par(mfrow=c(2,2))

#Grafico1
hist(respad,
     xlab="Residuos internamente estudentizados",
     ylab="Densidade",
     main="",
     border=col1, freq=FALSE)
  x<-c()
curve(dnorm(x,mean=0,sd=1),col=col2,
        lty=1,lwd=1,add=TRUE)

  #Grafico2
  good<-!is.na(resid)
  ord<-order(resid[good])
  ord.x<-resid[good][ord]
  n<-length(ord.x)
  P<-ppoints(n)
  z<-qnorm(P)
  plot(z,ord.x, xlab="Quantil teorico",
       ylab="Residuos internamente estudentizados",
       pch=20, col=col2)
  coef<-coef(lm(ord.x~z))
  b0<-coef[1]
  b1<-coef[2]
  abline(b0,b1,col=col1,lwd=1)
  conf<-0.95
  zz<-qnorm(1-(1-conf)/2)
  SE<-(b1/dnorm(z))*sqrt(P*(1-P)/n)
  fit.value<-b0+b1*z
  upper<-fit.value+zz*SE
  lower<-fit.value-zz*SE
  lines(z,upper,lty=2,lwd=2,col=col1)
  lines(z,lower,lty=2,lwd=2,col=col1)

  # Grafico3
  plot(fitted.val,respad,pch=20, col=col2,
       xlab="Valores ajustados",
       ylab="Residuos internamente estudentizados")
  abline(h=0,col=col1,lty=1)

# Grafico4
boxplot(respad~a$trat,
        border=col1,
        xlab='Tratamentos',
        ylab='Residuos internamente estudentizados')

data <- data.frame(a$trat,respad)
mylevels <- levels(factor(a$trat))
sa<-summary(a$trat)
levelProportions = NULL
if(is.numeric(sa)) levelProportions <- sa/(2*length(a))
for(i in 1:length(mylevels)){
thislevel <- mylevels[i]
thisvalues <- data[a$trat==thislevel,2]
myjitter <- jitter(rep(i, length(thisvalues)),
                   amount=NULL)
                     #levelProportions[i])
points(myjitter, thisvalues, pch=20, col=col2)
}

  par(mfrow=c(1,1))
  par(mar=c(4,4,4,4))
}
