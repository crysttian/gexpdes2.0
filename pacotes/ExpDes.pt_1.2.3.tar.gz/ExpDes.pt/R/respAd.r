#' Dadaos ficticios: tratamento adicional
#'
#' @description Variavel resposta do tratamento adicional.
#' @docType data
#' @keywords datasets
#' @name respAd
#' @usage data(respAd)
#' @format Vector numerico.
#' @author Eric Batista Ferreira,
#'  \email{eric.ferreira@@unifal-mg.edu.br}
NULL
