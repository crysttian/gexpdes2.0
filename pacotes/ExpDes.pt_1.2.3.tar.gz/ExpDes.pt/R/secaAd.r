#' Compostagem: tratamento adicional
#'
#' @description Variavel resposta (biomassa seca) do tratamento
#' adicional do experimetno sobre compastagem.
#' @docType data
#' @keywords datasets
#' @name secaAd
#' @usage data(secaAd)
#' @format Vetor numerico.
#' @author Eric Batista Ferreira,
#'  \email{eric.ferreira@@unifal-mg.edu.br}
NULL
