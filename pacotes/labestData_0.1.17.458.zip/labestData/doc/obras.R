## ---- include = FALSE----------------------------------------------------
rl <- readLines("config/bibliography.bib")
bib <- gsub(x = grep(x = rl,
                     pattern = "^@",
                     value = TRUE),
            pattern = "^.*\\{(.*),.*", replacement = "  * @\\1")

## ---- echo = FALSE, results = "asis"-------------------------------------
cat(bib, sep = "\n")

## ---- echo = FALSE, results = "asis"-------------------------------------
cat("```tex\n")
cat(rl, sep = "\n")
cat("```\n")

