***

<img src='labestDataLogo.svg' height='120px' align='left' style='margin-right: 30px;'></img>

O [labestData] é um projeto coletivo do [PET-Estatística UFPR] que visa
contribuir com o Departamento de Estatística, e a comunidade científica
em geral, por reunir, organizar, manter e disponibilizar conjuntos de
dados na forma de um pacote R de tal forma que possam ser usados para o
ensino de Estatística. Todo o projeto é desenvolvido sob versionamento
[Git] e mantido nos nos serviços de hospedagem remota [GitLab do C3SL] e
[GitHub].

[Git]: https://git-scm.com/
[GitHub]: https://github.com/pet-estatistica/labestData
[GitLab do C3SL]: https://gitlab.c3sl.ufpr.br/pet-estatistica/labestData
[labestData]: https://gitlab.c3sl.ufpr.br/pet-estatistica/labestData
[PET-Estatística UFPR]: https://github.com/pet-estatistica/
