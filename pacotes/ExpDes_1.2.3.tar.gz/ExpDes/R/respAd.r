#' Fictional data: additional treatment
#'
#' @description Response variable form the additional treatment.
#' @docType data
#' @keywords datasets
#' @name respAd
#' @usage data(respAd)
#' @format Numeric vector.
#' @author Eric Batista Ferreira,
#'  \email{eric.ferreira@@unifal-mg.edu.br}
NULL
